### Hexlet tests and linter status:
[![Actions Status](https://github.com/Faizik12/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Faizik12/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/c3ee10cf6b2468e4aec0/maintainability)](https://codeclimate.com/github/Faizik12/python-project-49/maintainability)